Arduino-INA226
==============

INA226 Bi-directional Current/Power Monitor Arduino Library

Tutorials: http://www.jarzebski.pl/arduino/czujniki-i-sensory/cyfrowy-czujnik-pradu-mocy-ina226.html

This library use I2C to communicate, 2 pins are required to interface.

I need your help
----------------

July 31, 2017

In the near future I plan to refactoring the libraries. The main goal is to improve code quality, new features and add support for different versions of Arduino boards like Uno, Mega and Zero.

For this purpose I need to buy modules, Arduino Boards and lot of beer. 

If you want to support the further and long-term development of libraries, please help.

You can do this by transferring any amount to my PayPal account: paypal@jarzebski.pl

Thanks!
